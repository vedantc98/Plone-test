def test_function_that_would_never_be_run():
    self.assert_(True)
