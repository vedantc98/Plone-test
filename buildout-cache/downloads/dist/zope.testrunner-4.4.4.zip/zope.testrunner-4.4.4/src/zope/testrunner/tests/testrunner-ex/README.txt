This directory and its subdirectories contain example tests for
testing the test runner, testrunner.py.
