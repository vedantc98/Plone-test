
# Set to false to make AttributeDoc.Roles()
# return the raw list or tuple.

FILTER_ROLES = 1

# Set to false to show the "raw" type of
# methods and method-like attributes.

FILTER_METHODS = 1

# Set to true to enable reST for docstrings
# (not implemented yet)

DOCSTRINGS_USE_REST = 0

