See ./Products/DocFinderTab/README.txt

