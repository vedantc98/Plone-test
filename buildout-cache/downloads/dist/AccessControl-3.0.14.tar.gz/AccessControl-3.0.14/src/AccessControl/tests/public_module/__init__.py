# test module, public

from Acquisition import aq_base  # Foil the old ZopeSecurityPolicy

def pub():
    pass
