"""
The lxml test suite for lxml, ElementTree and cElementTree.
"""

