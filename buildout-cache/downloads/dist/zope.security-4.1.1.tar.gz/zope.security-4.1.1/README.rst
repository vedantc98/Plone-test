``zope.security``
=================

.. image:: https://img.shields.io/pypi/v/zope.security.svg
    :target: https://pypi.python.org/pypi/zope.security/
    :alt: Latest Version

.. image:: https://travis-ci.org/zopefoundation/zope.security.png?branch=master
        :target: https://travis-ci.org/zopefoundation/zope.security

.. image:: https://readthedocs.org/projects/zopesecurity/badge/?version=latest
        :target: http://zopesecurity.readthedocs.org/en/latest/
        :alt: Documentation Status

The Security framework provides a generic mechanism to implement security
policies on Python objects.
