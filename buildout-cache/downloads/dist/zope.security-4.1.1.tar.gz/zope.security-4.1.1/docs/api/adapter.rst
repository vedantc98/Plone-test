:mod:`zope.security.adapter`
============================

.. automodule:: zope.security.adapter
   :members:
   :member-order: bysource
