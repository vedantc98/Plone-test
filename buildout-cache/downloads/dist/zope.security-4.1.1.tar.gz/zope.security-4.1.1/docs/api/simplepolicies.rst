:mod:`zope.security.simplepolicies`
===================================

.. automodule:: zope.security.simplepolicies
   :members:
   :member-order: bysource
