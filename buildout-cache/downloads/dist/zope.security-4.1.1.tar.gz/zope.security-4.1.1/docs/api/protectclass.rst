:mod:`zope.security.protectclass`
=================================

.. automodule:: zope.security.protectclass
   :members:
   :member-order: bysource
