# -*- coding: utf-8 -*-


def dummy_step(context):
    pass
