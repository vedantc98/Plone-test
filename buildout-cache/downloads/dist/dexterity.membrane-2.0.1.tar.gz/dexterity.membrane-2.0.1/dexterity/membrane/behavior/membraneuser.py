# -*- coding: utf-8 -*-
from user import IMembraneUser as BBBIMembraneUser


class IMembraneUser(BBBIMembraneUser):
    """ BBB class for zc.relations stuff and other weirdness """
