# -*- coding: utf-8 -*-
from group import IMembraneGroup as BBBIMembraneGroup


class IMembraneGroup(BBBIMembraneGroup):
    """ BBB class for zc.relations stuff and other weirdness """
