:mod:`zope.i18nmessageid` API Reference
=======================================

:mod:`zope.i18nmessageid.message`
---------------------------------

.. automodule:: zope.i18nmessageid.message

   .. autoclass:: Message

   .. autoclass:: MessageFactory
