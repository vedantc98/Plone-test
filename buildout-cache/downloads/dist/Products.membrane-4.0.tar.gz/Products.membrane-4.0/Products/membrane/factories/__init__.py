# -*- coding: utf-8 -*-
import zope.deprecation


zope.deprecation.moved("Products.membrane.at", "1.3")
