# -*- coding: utf-8 -*-
def sortTuple(t):
    l = sorted(t)
    return tuple(l)
