# -*- coding: utf-8 -*-
"""
Archetype factories
===================

This package has basic implementations of all the required interfaces
(as defined in :mod:`Products.membrane.interfaces.user`) for Archetypes
based content types.

"""
