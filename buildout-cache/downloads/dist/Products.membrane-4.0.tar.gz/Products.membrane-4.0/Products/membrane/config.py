# -*- coding: utf-8 -*-
PROJECTNAME = 'membrane'
TOOLNAME = 'membrane_tool'

GLOBALS = globals()

FILTERED_ROLES = ('Anonymous', 'Authenticated')

QIM_ANNOT_KEY = 'Products.membrane.query_index_map'
