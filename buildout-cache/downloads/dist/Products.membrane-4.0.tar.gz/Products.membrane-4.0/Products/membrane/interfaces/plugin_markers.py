# -*- coding: utf-8 -*-
import zope.deprecation


zope.deprecation.moved("Products.membrane.at.interfaces", "1.3")
