Contributors
============

This package is based on `bobtemplates.niteoweb <https://github.com/niteoweb/bobtemplates.niteoweb>`_ and `bobtemplates.ecreall <https://github.com/cedricmessiant/bobtemplates.ecreall>`_

- Philip Bauer [pbauer]
- Cédric Messiant [cedricmessiant]
- Vincent Fretin [vincentfretin]
- Thomas Desvenain [thomasdesvenain]
- Domen Kožar [iElectric]
- Nejc Zupan [zupo]
- Patrick Gerken [do3cc]
- Timo Stollenwerk [timo]
- Johannes Raggam [thet]
- Sven Strack [svx]
- Héctor Velarde [hvelarde]
- Aurore Mariscal [AuroreMariscal]
- Víctor Fernández de Alba [sneridagh]
